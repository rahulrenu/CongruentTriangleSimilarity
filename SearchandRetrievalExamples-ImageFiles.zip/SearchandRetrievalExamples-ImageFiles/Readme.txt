The NIST folder shows search and retrieval examples of STL files obtained from these links:
1. https://www.nist.gov/system/files/documents/2019/09/27/belt_dive_stl_files.zip
2. https://www.nist.gov/system/files/documents/2017/08/08/task2_stl_files.zip

The Thingi10K folder shows search and retrieval examples of STL files from:
Zhou, Q.; Jacobson, A.: �Thingi10K: A Dataset of 10,000 3D-Printing Models,� arXiv preprint arXiv:1605.04797, 2016.

In both folders, files wihtin a subfolder and with a "1" prefix are query files. Subsequently numbered files are retrieved files.
